# Tableau de Bord

## 1 - Seance 1 (06/09/2021 8h00 à 10h00) 
Durant cette 1er séance, je n'ai pas rencontré de difficulté pour initialiser le projet. Le niveau 1 a été facile à faire. J'ai commencé le niveau 2 et j'ai rencontré quelques difficultés pour faire le diagramme de classe puisque cela fait un certain que je n'en ai pas fait. Je continuerai le niveau à la prochaine séance.

## 2 - Seance 2 (06/09/2021 14h00 à 16h00) 
Pendant cette séance j'ai terminé et corrigé mes deux diagrammes de classes, cela m'a pris du temps de les terminés et vérifiés. C'est plus long que complexe.

## 3 - Seance 3 (07/09/2021 8h15 à 10h05)
J'ai trouvé assez simple le niveau 3, je suis rapidement passé au niveau suivant, où j'ai rencontré quelques difficultés au niveau du while. Notamment le fait de stocker la variable avant puis de la vérifier ensuite et répéter cette opération n'a pas été direct pour moi, mais j'ai réussi. Je suis passé ensuite passer au niveau 5, j'ai pris d'abord le temps de bien comprendre le code. J'ai pris beaucoup de temps à comprendre comment accéder à notre ArrayList depuis Dessin, après avoir compris que le Labyrinthe est lui-même un ArrayList de salles, il me suffisait donc d'utiliser l'attribut labyrinthe présent dans la classe Dessin pour accéder à mon ArrayList. J'ai ensuite dessiné les murs, l'entrée et la sortie.

## 4 - Seance 4 (07/09/2021 10h20 à 12h15)
Cette séance j'ai fais le niveau 6, j'ai eu dû mal à me lancé pour savoir de quel manière tester les coordonnées dans le fichier. J'ai ensuite tenté une idée mais je n'ai pas pu vérifié si elle fonctionné à cause d'une erreur qui indiqué que le fichier level10.txt n'existe pas. J'ai cherché pendant 30mins une solution à cette erreur, je l'ai trouvé en utilisant un scanner et en re-codant la méthode lireNombre de la classe Fichier dans le fichier Test.

## 5 - Seance 5 (08/09/2021 10h20 à 12h15)
Durant le début de cette séance j'ai fais le niveau 7, que j'avais commencé avant la séance. Je suis ensuite passé au niveau 8, que j'ai trouvé plutôt simple c'est pour quoi il ne m'a pas pris beaucoup de temps. J'ai attaqué le niveau 9, qui n'était pas non plus compliqué je suis plutôt à l'aise avec les exceptions. Pour finir j'a commencé le niveau 10, en effet nous avions déjà traité à travers différent projet la problématique de gérer des coordonnées adjacentes, il ne me manque que d'adapter la classe Labyrinthe.

## Travail hors Seance (09/06/2021 14h00 à 16h30)
J'ai adapter la classe Labyrinthe, j'ai pu donc valider le niveau 10, je suis passé au niveau 11, mais je n'ai pas compris qu'est-ce qu'il fallait mettre dans les deux méthodes à implémenter. Je suis donc passé au niveau 12 que j'ai terminé rapidement. Au niveau 13 ça se complique il y a beaucoup de chose à faire, surtout à deviner. J'ai passé beaucoup de temps à comprendre ce qu'on nous demandé, mais à force j'y suis arrivé. J'ai commencé le niveau 14, mais j'attends confirmation durant la séance de demain de ce que j'ai fais aujourd'hui.

## 6 - Seance 6 (10/09/2021 8h00 à 10h00)
J'ai terminé le niveau 14, mais j'ai rencontré des difficultés, notamment le fait qu'il fallait mettre un attribut de la classe Héros, qui n'était spécifier. J'ai donc chercher pendant quelques temps, je suis ensuite passé au niveau 15. Mais en lançant le programme, j'ai des erreurs de code, j'ai donc passer le reste de la séance à les vérifier.

## 7 - Seance 7 (10/09/2021 14h00 à 16h00)
Durant cette séance j'ai à la fois tenté de faire fonctionner correctement le déplacement du personnages et afficher le monstre. J'ai réussi à afficher le monstre cependant je n'ai pas réussi à faire le déplacement correctement.

## 8 - Seance 8 (13/09/2021 8h00 à 10h00)
Avec Julian, nous avons trouvé la solution pour déplacer le personnage et donc le monstre. L'erreur provenait d'une mauvaise interprétation du niveau où il fallait implémenter à la fois les méthodes de la classe ISprite ET IPersonnage dans la classe ASprite. Cette erreur m'a coûté environ 3 séances, mais j'ai de tout même fais des niveaux en parallèle de ce problème.

## 9 - Seance 9 (13/09/2021 14h00 à 16h00)
Durant cette séance, j'ai effectué les derniers niveaux de l'objectif 4, je suis à l'objectif 5 qui semble beaucoup plus dur. J'ai commencé l'exercice 19, mais je l'ai trouvé difficile.

## 10 - Seance 10 (14/09/2021 8h00 à 10h00)
Durant cette séance, j'ai peut-être trouvé une solution avec Julian, mais de mon côté elle ne fonctionne pas, je vais revoir mon code à la séance de cette après-midi. Ce niveau est complexe mais pas impossible.

## 11 - Seance 11 (14/09/2021 14h00 à 16h00)
Durant cette séance, j'ai corrigé les différents bugs de la solution pour le niveau 19, comme cela m'a pris du temps, j'ai décidé de faire la javadoc le reste de la séance.

## 12 - Seance 12 (15/09/2021 14h00 à 16h00)
Durant la première partie, j'ai pu enfin terminer complètement le niveau 19, ce niveau a été fait avec la participation de Julian et surtout grâce à l'aide du professeur. Je vais donc commencer le niveau 20. Le 20 a été un niveau plutôt, j'ai juste eu un petit bug que j'ai réglé chez moi, mais le code du niveau 20 n'a pas été touché. Je considère donc que j'ai terminé le niveau 20 durant la séance. 

## 13 - Seance 13 (16/09/2021 8h00 à 10h00)
Durant cette séance je pensais avoir réussi à faire le LabyrintheGraphe du niveau 23. Seulement j'ai eu une erreur entre l'utilisation de la classe Labyrinthe et la classe LabyrintheGraphe pour faire le labyrinthe j'ai passé la moitié de la séance à essayer de la trouver mais je n'ai pas réussi. Je pense que je vais supprimer la classe Labyrinthe et corriger les quelques bugs d'affichage des monstres lors du déplacement, cet après-midi.